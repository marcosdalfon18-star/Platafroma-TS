// Importa las funciones necesarias desde el SDK de Firebase
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

// Configuración de tu aplicación Firebase
const firebaseConfig = {
  apiKey: "AIzaSyD0rGSNBIZNosJA_0WAsoYxe-JbzzjDvz8",
  authDomain: "sosty-d1747.firebaseapp.com",
  databaseURL: "https://sosty-d1747-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "sosty-d1747",
  storageBucket: "sosty-d1747.firebasestorage.app",
  messagingSenderId: "268357868311",
  appId: "1:268357868311:web:06ded6470df7f282b63552",
  measurementId: "G-HFJ7JE13WV"
};

// Inicializa Firebase
export const app = initializeApp(firebaseConfig);
export const analytics = getAnalytics(app);